from pydub import AudioSegment
import ffmpeg
sound=AudioSegment.from_file(r"C:\Users\庞博\Desktop\样本.mp3","mp3")
sound = sound.set_channels(1) #多声道转单声道
sound.export("转换声道后样本.wav", format="wav")

ffmpeg.input(r"转换声道后样本.wav").output('转换完毕样本.wav', ar=16000).run() #转换采样率
# frames_per_second = sound.frame_rate
# print(frames_per_second)
# channel_count = sound.channels
# print(channel_count)
from aip import AipSpeech
APP_ID = '24541517'
API_KEY = '2DViLjkjV2svOcsGzutbi9nt'
SECRET_KEY = 'Xb89xy5LB5ax3F0utUqcsmRis5OBZiv7'
# 百度AI库获取的参数
client = AipSpeech(APP_ID, API_KEY, SECRET_KEY)

# 构造读取语音文件函数
def get_file_content(filePath):
    with open(filePath, 'rb') as fp:
        return fp.read()
# 识别本地文件  主函数
result = client.asr(get_file_content(r'D:\编程\python.pycharm\2020\2021\pythonLearning\转换完毕样本.wav'), 'wav', 16000, { 'lan': 'zh',})
#此处地址处必须要加r，使其成为绝对地址，要么容易字符转义出现错误
print(result)
